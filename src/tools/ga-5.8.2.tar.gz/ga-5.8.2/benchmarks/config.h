#define HAVE_STDIO_H 1
#define HAVE_STDLIB_H 1
#define HAVE_ASSERT_H 1
#define HAVE_UNISTD_H 1
#define HAVE_MATH_H 1
#define MSG_COMMS_MPI 1
