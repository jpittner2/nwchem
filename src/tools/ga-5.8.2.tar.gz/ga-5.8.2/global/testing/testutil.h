/* extern void get_range( int ndim, int dims[], int lo[], int hi[]); */
/* extern void new_range(int ndim, int dims[], int lo[], int hi[], int new_lo[], int new_hi[]); */
extern void print_subscript(char *pre,int ndim, int subscript[], char* post);
/* extern void print_distribution(int g_a); */
